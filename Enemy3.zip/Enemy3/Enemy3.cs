using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enemy3 : MonoBehaviour
{
    public float moveSpeed = 5f; // Speed for moving between corners
    public float verticalSpeed = 3f; // Speed for downward movement

    private bool movingToLeft = true; // Toggle to switch between corners

    // Update is called once per frame
    void Update()
    {
        // Set target x position based on the direction
        float targetX = movingToLeft ? -7f : 7f;

        // Move horizontally towards the target x position
        transform.position = Vector3.Lerp(transform.position, new Vector3(targetX, transform.position.y, transform.position.z), moveSpeed * Time.deltaTime);

        // Toggle direction when close enough to the target x position
        if (Mathf.Abs(transform.position.x - targetX) < 0.1f)
        {
            movingToLeft = !movingToLeft;
        }

        // Move downward at a steady pace
        transform.Translate(Vector3.down * verticalSpeed * Time.deltaTime);

        // Destroy the object if it moves out of bounds
        if (transform.position.y < -8f)
        {
            Destroy(this.gameObject);
        }
    }
}
